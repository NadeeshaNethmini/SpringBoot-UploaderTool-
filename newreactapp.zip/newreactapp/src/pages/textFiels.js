import * as React from 'react';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import { Button } from "@material-tailwind/react";

export default function TextFields() {
    const [name, setName] = React.useState('');
    const [email, setEmail] = React.useState('');

    const addUser = (e) => {
        e.preventDefault();
        const id = Math.floor(Math.random() * 10000) + 1;
        const user={id, name, email};
        console.log(user);
        fetch('http://localhost:8080/api/v1/user/saveUser', {
            method: 'POST',
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify(user)
        }).then(() => {
            console.log('new user added');
        })
    }

    return (
        <Box
        component="form"
        sx={{
            '& > :not(style)': { m: 1, width: '25ch' },
        }}
        noValidate
        autoComplete="off"
        >
        <TextField id="outlined-basic" label="Name" variant="outlined" 
        onChange={(e) => setName(e.target.value)}
        />
        <TextField id="filled-basic" label="Email" variant="outlined" 
        onChange={(e) => setEmail(e.target.value)}
        />

        <center>
            <Button className=" flex items-center justify-center gap-3 bg-sky-400 p-2 rounded-lg"  onClick={addUser}>
                <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 25 25"
                    strokeWidth={2}
                    stroke="currentColor"
                    className="h-10 w-15"
                >
                    <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M12 16.5V9.75m0 0l3 3m-3-3l-3 3M6.75 19.5a4.5 4.5 0 01-1.41-8.775 5.25 5.25 0 0110.233-2.33 3 3 0 013.758 3.848A3.752 3.752 0 0118 19.5H6.75z"
                    />
                </svg>
                Add User
            </Button>
        </center>    

        </Box>
    );
}
