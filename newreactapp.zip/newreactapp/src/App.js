import './App.css';
// import ReadExcel from './Pages/ReadExcel';
// import { ButtonWithIcon } from './Pages/button';
import './index.css';
import FileUpload from './pages/FileUpload';
// import TextFields from './pages/textFiels';

function App() {
  return (
    <div className="App">
      <FileUpload />
      {/* <TextFields /> */}
      {/* <ReadExcel /> */}
      {/* <ButtonWithIcon /> */}
    </div>
  );
}

export default App;
