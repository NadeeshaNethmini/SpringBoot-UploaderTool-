import { useState } from 'react';
import * as XLSX from 'xlsx';
import { Card, Typography } from "@material-tailwind/react";
import { Button } from "@material-tailwind/react";

function ReadExcel() {
  const [column, setColumn] = useState([]);
  const [data, setData] = useState([]);

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();
    
    reader.onload = (event) => {
      const bstr = event.target.result;
      const workBook = XLSX.read(bstr, { type: "binary" });
      const workSheetName = workBook.SheetNames[0];
      const workSheet = workBook.Sheets[workSheetName];
  
      const data = XLSX.utils.sheet_to_json(workSheet, { 
        header: 1, 
        defval: "Not Available" 
      });

      const rowData = data.slice(1);
  
      setColumn(data[0]);
      setData(rowData);
      console.log(rowData[0]);
    };
  
    reader.readAsBinaryString(file);
  }

  const selectExcel = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.onchange = handleFileUpload;
    input.click();
  }
  
  return (
    <div className="App">
      <h1 className='text-4xl text-blue-400 p-4'>Uploader Tool</h1>
      <center>
      <Button className=" flex items-center justify-center gap-3 bg-sky-400 p-2 rounded-lg"  onClick={selectExcel}>
        <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 25 25"
            strokeWidth={2}
            stroke="currentColor"
            className="h-10 w-15"
        >
            <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M12 16.5V9.75m0 0l3 3m-3-3l-3 3M6.75 19.5a4.5 4.5 0 01-1.41-8.775 5.25 5.25 0 0110.233-2.33 3 3 0 013.758 3.848A3.752 3.752 0 0118 19.5H6.75z"
            />
        </svg>
        Upload Files
      </Button>
      </center>

      <br />

      {data.length > 0 &&
      <Card className="h-full w-full overflow-scroll">
        <table className="w-full min-w-max table-auto text-left">
            <thead>
            <tr>
                {column.map((head) => (
                <th
                    key={head}
                    className="border-b border-slate-100 bg-slate-300 p-4"
                >
                    <Typography
                    variant="small"
                    color="slate"
                    className="font-normal leading-none opacity-70"
                    >
                    {head}
                    </Typography>
                </th>
                ))}
            </tr>
            </thead>
            <tbody>
            {data.map((row, index) => {
                const isLast = index === data.length - 1;
                const classes = isLast ? "p-4" : "p-4 border-b border-slate-500";
                
                return (
                <tr key={index} className="even:bg-slate-200/50">
                    {row.map((cell, index) => (
                    <td className={classes} key={index}>
                        <Typography
                        variant="small"
                        color="slate-100"
                        className="font-normal"
                        >
                        {cell}
                        </Typography>
                    </td>
                    ))}
                </tr>
                );
            })}
            </tbody>
        </table>
      </Card>
      }
    </div>
  );
}

export default ReadExcel;
